import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;



public class EmployeeServiceImpl {
	
	HashMap<String, Employee>list = new LinkedHashMap<String, Employee>();
	
	public void addEmployee(Employee emp){
		
		list.put(""+emp.getId(), emp);
	}
	
	public void find(InsuranceScheme insSch){
		
		for (Employee employee : list.values()) {			
			if(employee.getInsuranceScheme()==insSch){
				System.out.println(employee);
			}
		}
	}
	
	public boolean deleteEmployee(int id){
		list.remove(""+id);
		return true;
	}
	
	public void sortEmployee(){
		Set<String>empids = list.keySet();
		
		List<Employee>employees = new ArrayList<>();
		
		for (String empid : empids) {
			employees.add(list.get(empid));
		}
		
		Collections.sort(employees);
		
		for (Employee employee : employees) {
			System.out.println(employee);
		}
	}
}