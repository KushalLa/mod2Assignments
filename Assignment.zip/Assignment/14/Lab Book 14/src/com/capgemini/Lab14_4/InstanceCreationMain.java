package com.capgemini.Lab14_4;

import java.util.ArrayList;
import java.util.List;

public class InstanceCreationMain {

	public static void main(String[] args) {
		List<InstanceCreation> list=new ArrayList<>();
		list.add(new InstanceCreation("Esha", "Jain"));
		list.add(new InstanceCreation("Vartika", "Dubey"));
		list.add(new InstanceCreation("Rinali", "Kapadia"));
		list.forEach(System.out::println);
	}

}
