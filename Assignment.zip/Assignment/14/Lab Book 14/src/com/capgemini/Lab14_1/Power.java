package com.capgemini.Lab14_1;

import java.util.function.BiFunction;

public class Power {

	public static void main(String[] args) {
		BiFunction<Double,Double,Double> powFunction = (x, y) -> Math.pow(x, y);
		System.out.println("Power is:" + powFunction.apply(2.0, 2.0));
	}

}
