package com.capgemini.lab146.entity;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

public class EmployeeRepository {
	private List<Employee>employeeList;
	
	public EmployeeRepository(){
		Department departmentMktg = new Department(1, "Marketing", 100);
		Department departmentProd = new Department(2, "Production", 200);
		Department departmentHR = new Department(3, "HR", 300);
		
		Employee empOne = new Employee(1, "Amit", "Kashid", "kash@company.com", "9999999999",LocalDate.of(2011, Month.DECEMBER, 11), "Senior Sales Officer", 80000,100, departmentMktg);
		Employee empTwo = new Employee(2, "Rahul", "Chandakar", "chandakar@company.com", "8888888888",LocalDate.of(2009, Month.JULY, 5), "Senior Production Officer", 80000,200, departmentProd);
		Employee empThree = new Employee(3, "pandu", "Khilji", "khilji@company.com", "7777777777",LocalDate.of(2009, Month.JANUARY, 27), "Senior HR Executive", 80000,300, departmentHR);
		
		Employee empFour = new Employee(4, "Madhuri", "Vagh", "vagh@company.com", "9898989898",LocalDate.of(2008, Month.OCTOBER, 2), "Junior Production Officer", 35000,200, departmentProd);
		Employee empFive = new Employee(5, "Lovina", "Singh", "singh@company.com", "8989898989",LocalDate.of(2010, Month.JULY, 5), "Junior Production Officer", 35000,200, departmentProd);
		Employee empSix = new Employee(6, "Anita", "Desakar", "desakar@company.com", "7878787878",LocalDate.of(2009, Month.JANUARY, 27), "Junior HR Executive", 30000,300, departmentHR);
		
		employeeList = new ArrayList<>();
		
		employeeList.add(empOne);
		employeeList.add(empTwo);
		employeeList.add(empThree);
		employeeList.add(empFour);
		employeeList.add(empFive);
		employeeList.add(empSix);
	}
	
	public double getAllSalarySum(){
		return employeeList.parallelStream().mapToDouble((n)->n.getSalary()).sum();
	}
	
	public void listEmployeesMonthDays(){
		employeeList.forEach((n)->{
			LocalDate today = LocalDate.now();
			Period difference = n.getHireDate().until(today);
			int years = difference.getYears();
			int months = difference.getMonths();
			int days = difference.getDays();
			
			System.out.println("Name: " + n.getFirstName() + " "+n.getLastName());
			System.out.println("Months after hiring: " + (months + (years*12)));
			System.out.println("Days after hiring: " + days);
			System.out.println("=============================================================");
		});
	}
	
	public void employeesWithoutDepartment(){
		employeeList.forEach((n)->{
			System.out.println("Employee ID: " + n.getEmployeeId());
			System.out.println("Name: " + n.getFirstName() + " "+n.getLastName());
			System.out.println("Phone no: " + n.getPhoneNumber());
			System.out.println("Hire Date: " + n.getHireDate());
			System.out.println("Email: " + n.getEmail());
			System.out.println("Designation: " + n.getDesignation());
			System.out.println("Manager ID: " + n.getManagerId());
			System.out.println("Salary: " + n.getSalary());
			System.out.println("================================================================");
		});
	}
	
	public void onlyDepartments(){
		employeeList.stream().map((n)->n.getDepartment()).distinct().forEach(System.out::println);
		System.out.println("================================================================");
	}
	
	public void dayOfWeek(){
		employeeList.forEach((n)->{
			System.out.println("Name: " + n.getFirstName() + " "+n.getLastName());
			System.out.println("Hire Date: " + n.getHireDate());
			System.out.println("Day of week of hiring: " + n.getHireDate().getDayOfWeek());
			System.out.println("================================================================");
		});
	}
}