package Caller;

public class CurrentAccount extends Account {

	final double overdraftLimit=10000;
	
	public boolean withdraw(double d)
	{
		double temp=this.balance-d;
		if(temp>overdraftLimit)
		{
			this.balance=temp;
			return true;
		}
		else
			return false;
	}
}
