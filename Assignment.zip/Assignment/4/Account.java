package Caller;

public class Account {

	protected static long count=100000;
	protected long accNum;
	protected double balance;
	PersonAccount accHolder=new PersonAccount();
	
	public Account() {
		super();
	}
	
	public Account(double balance, PersonAccount accHolder) {
		super();
		if(balance>500){
			this.accNum = count++;
			this.balance = balance;
			this.accHolder = accHolder;
		}
		else{
	         throw new IllegalArgumentException();
		}
	}
	
	public static long getCount() {
		return count;
	}
	
	public long getAccNum() {
		return accNum;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public PersonAccount getAccHolder() {
		return accHolder;
	}
	
	public void setAccHolder(PersonAccount accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit(double d)
	{
		this.balance=this.balance+d;
	}
	
	public boolean withdraw(double d)
	{
		double temp=this.balance-d;
		if(temp>500){
			this.balance=temp;
			return true;
		}
		else
			return false;
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
}
