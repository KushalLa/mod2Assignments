package Caller;

public class PersonAccount {

	protected String name;
	protected float age;
	
	public PersonAccount() {
		super();
	}
	
	public PersonAccount(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "PersonAccount [name=" + name + ", age=" + age + "]";
	}
	
}
