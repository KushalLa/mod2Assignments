package Caller;
import java.util.Scanner;
public class person {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Person Details: ");
		
		System.out.println("First Name: ");
		String fname=sc.nextLine();
		
		System.out.println("Last Name: ");
		String lname=sc.nextLine();
		
		System.out.println("Gender: ");
		String gender=sc.nextLine();
		
		System.out.println("Age: ");
		int age=sc.nextInt();
		sc.nextLine();
		
		System.out.println("Weight: ");
		float weight=sc.nextFloat();
		sc.nextLine();
		
		System.out.println("Person Details: ");
		System.out.println("-------------------------");
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
		
		sc.close();
	}

}
