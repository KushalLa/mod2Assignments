package Practicalthree;
import java.lang.StringBuilder;
public class Seven {
	
	
	public	StringBuilder firstName=new StringBuilder("Atreyee");
	public	StringBuilder lastName=new StringBuilder("Paul");
	
	Seven()
	{
		
	}
	public void getFullName(StringBuilder firstName,StringBuilder lastName)
	{
		this.firstName=firstName;
		this.lastName=lastName;
	}
	
	
	
    void display()
	{
    	StringBuffer strb = new StringBuffer();
    	strb.append(firstName);
    	strb.append(lastName); 
    	System.out.println(strb);
	}

}
