package Practicalthree;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MainSeven {

	public static void main(String[] args) {
		
	    /*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy");
		Scanner scinput = new Scanner(System.in);
		System.out.println("Enter date in dd/MM/yyyy format:");
		String dob  = scinput.nextLine();
		scinput.close();
		LocalDate datee = LocalDate.parse(dob,formatter);
		LocalDate todayy = LocalDate.now();
		
		Period period = datee.until(todayy);
		*/
		Seven obj = new Seven();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scinput= new Scanner(System.in);
		System.out.println("Enter date in dd/mm/yyyy format:");
		String input  = scinput.nextLine();
		scinput.close();
		//Almost every class in java.time package provides parse() method to parse the date or time
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		LocalDate end = LocalDate.now();
		
		Period period = enteredDate.until(end);
		
		obj.display();
		System.out.println("Age :"+ period.getYears());
		
		
	

	}
}	
