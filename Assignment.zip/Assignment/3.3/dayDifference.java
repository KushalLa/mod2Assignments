package Caller;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class dayDifference {

	public static void main(String[] args) {
		
		DateTimeFormatter format =DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a date in DD/MM/YYYY format: ");
		String dt=sc.nextLine();
		
		sc.close();
		
		LocalDate dt1= LocalDate.parse(dt,format);
		LocalDate dt2= LocalDate.now();
		
		Period p = dt1.until(dt2);
		
		System.out.println("Days: "+p.getDays());
		System.out.println("Months: "+p.getMonths());
		System.out.println("Years: "+p.getYears());
	}

}
