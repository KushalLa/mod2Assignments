package com.Q12.A2.sample.bean;

import org.apache.log4j.Logger;

public class Message {
//create a logger for Message class
private String msg;
public void setMessage(String msg) {
this.msg = msg;
//log the messages for each priority level
}
public String getMessage() {
//log messages for each priority level
	return msg;
}
}