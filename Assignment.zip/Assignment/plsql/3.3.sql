CREATE OR REPLACE FUNCTION staff(
	v_staff_code Staff_Master.Staff_Code%TYPE
)
RETURN NUMBER
IS
	v_staff_sal  Staff_Master.Staff_Sal%TYPE;
	v_time NUMBER;
	v_doj DATE;
	v_emp_no NUMBER;
	v_s_a NUMBER;
	
BEGIN
	
	SELECT Staff_Sal
	INTO v_staff_sal
	FROM Staff_Master
	WHERE Staff_Code = v_staff_code;
	
	SELECT Hire_Date
	INTO v_doj
	FROM Employee
	WHERE Employee_no = v_emp_no;
	
	v_time := TO_CHAR(sysdate,'YYYY') - TO_CHAR(v_doj,'YYYY');
	
	IF v_time < 1 THEN
		v_s_a := v_staff_sal;
	
	ELSIF v_time>=1 AND  v_time<2 THEN
		v_s_a := v_staff_sal*.10;
		
	ELSIF v_time>=2 AND  v_time<4 THEN
		v_s_a := v_staff_sal*.20;
	
	ELSE
		v_s_a := v_staff_sal*.30;
	END IF;
	
	DBMS_OUTPUT.PUT_LINE('DA :'|| v_staff_sal*.15 ||'    HRA :'|| v_staff_sal*.20 ||  '   TA : '||v_staff_sal*.8  );
	DBMS_OUTPUT.PUT_LINE('special allowance : '|| v_s_a);
END;
/