package Caller;

import java.util.Scanner;

public class positiveString {

	public static void main(String[] args) {
		String s1=new String();
		Scanner sc=new Scanner(System.in);
		int f=0;
		
		System.out.println("Enter String: ");
		s1=sc.nextLine();
		for (int i = 0; i < s1.length()-1; i++) {
			if(!(s1.charAt(i)<s1.charAt(i+1)))
			{
				f=1;
				break;
			}
		}
		if(f==0)
			System.out.println("Positive String");
		else
			System.out.println("Negative String");
		sc.close();
	}

}
