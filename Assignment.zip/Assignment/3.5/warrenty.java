package Caller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class warrenty {

	public static void main(String[] args) {
		
		DateTimeFormatter format1 =DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter purchase date in DD/MM/YYYY format: ");
		String dt=sc.nextLine();
		LocalDate dt1= LocalDate.parse(dt,format1);
		
		System.out.println("Enter warrenty period in months: ");
		int total=sc.nextInt();
		int mm=total%12;
		int yr=total/12;
		
		
		LocalDate date = dt1.plusMonths(mm).plusYears(yr);
		
		System.out.println("Warrantee of product expires on: "+date);
		
		sc.close();

	}

}
