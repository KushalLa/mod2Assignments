package com.cg.eis.bean;

public enum InsuranceScheme {
	SchemeA,SchemeB,SchemeC,NoScheme
}
