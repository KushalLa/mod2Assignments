package com.cg.eis.exception;

public class EmployeeException extends Exception {
	
	public EmployeeException(String s){
		super(s);
	}
}
