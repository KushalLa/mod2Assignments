package com.cg.eis.service;

public interface EmployeeService {

	abstract public void setData(long id,String name,double salary,String designation);
	abstract public void findScheme();
	abstract public void display();
	
}
